# Ozone application: final data and reproduction code

This standalone package reproduces Section 5 (Application) of the manuscript:
two summers, nine US states, rank two, seven methods, and **50 spatial block
holdouts per year**. It contains analysis-ready observations, fixed design
inputs and source code. No fitted models, computed results, figures, logs or
historical analyses are included. It does not require the original project,
the manuscript, the simulation folder, LaTeX, or network access after installing
the Python dependencies.

The package was assembled against the current manuscript on 12 November 2026.
The source manuscript hash is recorded in `manifest.json` for version tracking;
the manuscript itself is not distributed here. Random station holdouts,
alternative ranks and first-ten-split comparisons are outside this package.

## Contents

| Path | Contents |
| --- | --- |
| `data/panels/2023/`, `data/panels/2024/` | 18 uncentered concentration matrices, in ppb; dates in rows and site IDs in columns |
| `data/stations.csv` | 301 station-year records, POC, coordinates and valid-day counts |
| `data/state_locations.csv` | Geographic representatives used to construct the fixed state network |
| `data/graphs/` | Raw and degree-normalized geographic, complete and three rewired graphs |
| `data/design/` | All 100 spatial directions and exact training/validation/test assignments |
| `data/source_metadata.json` | EPA download URLs, archived download times and original ZIP checksums |
| `config.json` | Complete fitting configuration and state update order |
| `code/estimation.py` | PCA, spectral block updates, convergence diagnostics and validation-only penalty selection |
| `code/reproduce.py` | Input verification, spatial-holdout fitting and numerical summaries |
| `code/figures.py` | Two-panel network/distance figure and state-level gain figure |
| `code/audit_panel_alignment.py` | Portable plotting-layout check used by the figure code |
| `DATA_DICTIONARY.md` | Variable definitions, data processing and statistical interpretation |
| `manifest.json` | Checksums for all supplied data, configuration, documentation and code |

## Run

Use Python **3.12**. The pinned versions match the numerical and plotting
versions used for this package. In a terminal, change into `RealData`, then run:

```sh
python -m venv .venv
# macOS / Linux:
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python code/reproduce.py --mode check
python code/reproduce.py --mode all --workers 4
```

`check` reads the supplied files without fitting models or writing results.
It checks file hashes, panel dates and completeness, graph construction and
rewiring, and all exact partitions against their seeded spatial directions.
The full command refits all 100 split/year combinations and creates `outputs/`.
Use `--workers 1` on a machine with limited resources. Linear algebra uses one
thread per process. Small floating-point differences across platforms/BLAS
implementations are possible.

For a quick execution test (one spatial split per year, **not** manuscript results):

```sh
python code/reproduce.py --mode smoke --workers 2 --output smoke_outputs
```

Optional separate stages:

```sh
python code/reproduce.py --mode run --workers 4
python code/reproduce.py --mode summarize
```

All modes accept `--output /path/to/results`. Existing split fits are reused only
when their data/code fingerprint matches. Interrupted full runs can be resumed
with the same command. Summaries require all 50 splits in both years; a smoke
test cannot silently produce a manuscript table. With `--mode all`, plotting
occurs only after all fits and summaries complete.

## Files produced when the recipient runs the code

These files are intentionally **absent from the submission package**:

| Generated file | Manuscript item |
| --- | --- |
| `table4.csv`, `table4.tex` | Seven-method reconstruction MSE and paired percentage reductions |
| `pair_distances.csv`, `pair_distance_summary.csv` | Linked/unlinked independent-PCA space comparisons |
| `figure3_network_distances.pdf` (also SVG/PNG) | Geographic network and independent-PCA distances |
| `state_summary.csv`, `figure4_state_gains.pdf` (also SVG/PNG) | State means, medians, IQRs and negative transfer |
| `network_vs_controls.csv` | Paired network gains relative to complete and rewired graphs |
| `split_metrics.csv`, `state_split_metrics.csv` | All split-level quantities underlying the summaries |
| `fits/`, `run_environment.json`, `*.alignment.json` | Newly computed losses, tuning traces, environment and figure-layout records |

Figure code reproduces the numerical content and display types of the manuscript;
font/layout details need not be pixel-identical to the submitted manuscript PDFs.

## Statistical design

For each year, 50 common spatial directions are applied within every state.
Within-state coordinates are ordered along that direction. With `p` sites,
`n = max(2, floor(0.2*p))` sites form the test block, the next `n` form the
validation block, and all remaining sites form the training block. There is no
spatial buffer. The supplied assignments retain the original within-block order.

Each site is time-centered and divided by 10 ppb. Training Gram matrices are
`X X' / (T * p_train)`; all states receive equal weight. The rank is fixed at two.
For each regularized graph, penalty selection uses only validation loss over
`0, .01, .02, .04, .08, .16, .32`, with upper-end doubling when selected (at most
13 extensions). Initializations, stopping thresholds and the small-penalty tie
rule are specified in the code and `config.json`. The selected **training** fits
are retained; validation sites are not added for refitting.

The test trajectory supplies its own time mean and projection coefficients, but
does not estimate the temporal factor space or choose the penalty. This is
same-period reconstruction, not forecasting or prediction at entirely unobserved
sites. Test losses are restored to ppb squared. For Table 4, MSE is first averaged
equally over nine states within a split, then over 50 splits. Percentage reduction
is computed within each split as `100 * (1 - method_MSE / individual_PCA_MSE)`
and then averaged; it is not the percentage ratio of the two grand means.
State-level reductions instead use each state's paired losses.

Repeated spatial splits reuse observations. Their IQRs describe split variability,
not confidence intervals from independent replications. Negative state-level
reductions are retained. Pair distances use all complete sites descriptively and
do not select edges or penalties; pairs sharing a state are not independent.
The two summers and coverage-based site selection limit generalizability.

## Data provenance

The reused public data are from the US Environmental Protection Agency (EPA),
Air Quality System (AQS), AirData daily ozone files for parameter 44201:

- <https://aqs.epa.gov/aqsweb/airdata/download_files.html>
- <https://aqs.epa.gov/aqsweb/airdata/daily_44201_2023.zip>
- <https://aqs.epa.gov/aqsweb/airdata/daily_44201_2024.zip>

The supplied final matrices and design inputs are sufficient to reproduce the
reported analysis. This is not a distribution of the full nationwide raw EPA
archives or of the exploratory data-audit pipeline. Original archive checksums
and the exact processing rules are supplied for provenance. A fresh EPA download
may differ if the provider revises its archives. See `DATA_DICTIONARY.md`.
