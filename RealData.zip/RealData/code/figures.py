"""Regenerate the two application figures from final inputs and computed summaries.

Figure 3: geographic edges define the sharing design; all pair distances provide
its descriptive rationale. Figure 4: paired gains by state and year expose
heterogeneity, including negative transfer. Intervals are split IQRs, not CIs.
The numerical content follows the manuscript; rendering can vary by platform.
"""
from pathlib import Path
import os
import tempfile
os.environ.setdefault('MPLCONFIGDIR', str(Path(tempfile.gettempdir()) / 'realdata-matplotlib'))
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.transforms import ScaledTranslation
from audit_panel_alignment import require_matplotlib_panel_alignment

DATA = Path(__file__).resolve().parents[1] / 'data'
BLUE, ORANGE, GREY = '#286c8e', '#b77a48', '#8a9096'


def panel_label(ax, letter):
    ax.text(0, 1, letter, transform=ax.transAxes + ScaledTranslation(
        -24/72, 13/72, ax.figure.dpi_scale_trans),
        fontsize=11, fontweight='bold', ha='left', va='bottom')


def export(fig, output, name):
    fig.canvas.draw()
    require_matplotlib_panel_alignment(fig, json_out=str(output / f'{name}.alignment.json'),
        tolerance_pt=1.5, gutter_tolerance_pt=1.5, strict=True)
    fig.savefig(output / f'{name}.pdf')
    fig.savefig(output / f'{name}.svg')
    fig.savefig(output / f'{name}.png', dpi=300)
    plt.close(fig)


def make_figures(output):
    output = Path(output)
    plt.rcParams.update({'font.family':'sans-serif', 'font.sans-serif':['DejaVu Sans'],
        'font.size':9, 'axes.labelsize':9, 'axes.titlesize':10, 'xtick.labelsize':8.5,
        'ytick.labelsize':8.5, 'pdf.fonttype':42, 'svg.fonttype':'none',
        'axes.spines.top':False, 'axes.spines.right':False, 'axes.linewidth':.7,
        'legend.frameon':False, 'figure.facecolor':'white'})
    raw = pd.read_csv(DATA / 'graphs/graph_NET_raw.csv', index_col=0)
    centers = pd.read_csv(DATA / 'state_locations.csv', index_col=0).loc[raw.index]
    xy = centers[['Longitude', 'Latitude']].to_numpy()
    pairs = pd.read_csv(output / 'pair_distances.csv')
    assert len(pairs) == 72 and pairs.groupby(['year','edge']).size().tolist() == [25,11,25,11]
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.4))
    fig.subplots_adjust(left=.09, right=.98, bottom=.23, top=.83, wspace=.48)
    ax = axes[0]
    for i in range(9):
        for j in range(i+1,9):
            if raw.iloc[i,j]:
                ax.plot(xy[[i,j],0], xy[[i,j],1], color='#a0a8af', lw=1, zorder=1)
    ax.scatter(xy[:,0], xy[:,1], s=25, c=BLUE, zorder=3)
    offsets = [(-14,4),(-18,-12),(-17,-11),(7,5),(7,-9),(8,-11),(8,5),(8,-6),(-16,5)]
    for point, label, offset in zip(xy, ['IL','IN','KY','MI','NC','OH','PA','VA','WI'], offsets):
        ax.annotate(label, point, xytext=offset, textcoords='offset points', fontsize=8.5)
    ax.set(xlim=(-92,-75), ylim=(33,46), xlabel='Longitude (degrees)', ylabel='Latitude (degrees)', title='Geographic network')
    ax.set_aspect(1/np.cos(np.deg2rad(40)), adjustable='datalim')
    panel_label(ax, 'a')
    ax = axes[1]
    for pos, (year, edge) in enumerate([(2023,1),(2023,0),(2024,1),(2024,0)]):
        values = pairs[(pairs.year==year)&(pairs.edge==edge)].distance.to_numpy()
        jitter = np.random.default_rng(20261023+pos).uniform(-.15,.15,len(values))
        ax.scatter(pos+jitter, values, s=16, c=BLUE if edge else GREY, alpha=.7, edgecolors='none')
        ax.scatter(pos, values.mean(), marker='D', s=24, c=ORANGE, zorder=4)
    ax.set(xticks=[0,1,2,3], xticklabels=['Linked','Unlinked','Linked','Unlinked'],
        xlim=(-.5,3.5), ylim=(0,1.05), ylabel='Normalized projector distance', title='Independent PCA spaces')
    ax.text(.25,-.22,'2023',transform=ax.transAxes,ha='center',fontsize=9)
    ax.text(.75,-.22,'2024',transform=ax.transAxes,ha='center',fontsize=9)
    panel_label(ax, 'b')
    fig.text(.54,.02,'Circles: state pairs; diamonds: group means',ha='center',fontsize=8.5)
    export(fig, output, 'figure3_network_distances')

    d = pd.read_csv(output / 'state_summary.csv')
    assert len(d) == 18 and d.n.eq(50).all()
    states = list(raw.index)
    low = min(d.q25.min(),d.mean_gain.min(),0) - 1.4
    high = max(d.q75.max(),d.mean_gain.max(),0) + 1.4
    fig, axes = plt.subplots(1,2,figsize=(7.2,4.3),sharey=True)
    fig.subplots_adjust(left=.20,right=.98,bottom=.21,top=.84,wspace=.20)
    for i,(ax,year) in enumerate(zip(axes,[2023,2024])):
        z = d[d.year==year].set_index('state').loc[states]
        pos = np.arange(9)
        ax.axvline(0,color=GREY,lw=.7,ls='--')
        ax.errorbar(z.median_gain,pos,xerr=[z.median_gain-z.q25,z.q75-z.median_gain],
            fmt='o',color=BLUE,capsize=3,lw=1.3,ms=4,label='Median and IQR')
        ax.scatter(z.mean_gain,pos+.16,marker='d',c=ORANGE,s=18,zorder=4,label='Mean')
        ax.set(yticks=pos,yticklabels=states,ylim=(8.7,-.6),xlim=(low,high),
               xlabel='Paired MSE reduction (%)',title=str(year))
        panel_label(ax,chr(97+i))
    handles,labels=axes[0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='lower center',bbox_to_anchor=(.59,.025),ncol=2,fontsize=8.5)
    export(fig, output, 'figure4_state_gains')
