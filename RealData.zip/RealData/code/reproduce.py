"""Reproduce the manuscript's ozone application from the supplied final data."""
from __future__ import annotations

import os
for name in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS',
             'VECLIB_MAXIMUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[name] = '1'
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
import hashlib
import json
from pathlib import Path
import platform
from types import SimpleNamespace
import numpy as np
import pandas as pd
import estimation as e

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data'
CONFIG = json.loads((ROOT / 'config.json').read_text())
STATES = CONFIG['states']
METHODS = CONFIG['methods']
NAMES = ['Individual PCA', 'Geographic network', 'Complete graph', 'Pooled PCA',
         'Rewired graph 1', 'Rewired graph 2', 'Rewired graph 3']


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    tmp.replace(path)


def fingerprint():
    paths = sorted(DATA.rglob('*')) + [ROOT / 'config.json',
             ROOT / 'code/estimation.py', ROOT / 'code/reproduce.py']
    return hashlib.sha256(''.join(sha(p) for p in paths if p.is_file()).encode()).hexdigest()


def panels(year):
    return [pd.read_csv(next((DATA / f'panels/{year}').glob(
        '*_' + state.replace(' ', '_') + '.csv')), index_col=0) for state in STATES]


def blocks_for(year, split):
    parts = pd.read_csv(DATA / 'design/partitions.csv', dtype={'site_id': str})
    parts = parts[(parts.year == year) & (parts.split == split)]
    blocks = []
    for state, frame in zip(STATES, panels(year)):
        # Center every trajectory on its own 92 dates; no site variance scaling.
        x = (frame - frame.mean(axis=0)) / CONFIG['scale_ppb']
        state_parts = parts[parts.state == state]
        blocks.append({kind: x.loc[:, state_parts[state_parts.partition == kind]
                       .sort_values('position').site_id].to_numpy(float)
                       for kind in ['train', 'validation', 'test']})
    return blocks


def cov(blocks, kind):
    return np.array([b[kind] @ b[kind].T / np.prod(b[kind].shape) for b in blocks])


def connected(a):
    seen = {0}
    while True:
        nxt = seen | {int(j) for i in seen for j in np.flatnonzero(a[i])}
        if nxt == seen:
            return len(seen) == len(a)
        seen = nxt


def rewire(raw, seed):
    """Original 110 accepted, connected, degree-preserving double-edge swaps."""
    rng = np.random.default_rng(seed)
    a = raw.copy()
    swaps = 0
    for _ in range(20000):
        edges = np.argwhere(np.triu(a, 1))
        (u, v), (x, y) = edges[rng.choice(len(edges), 2, replace=False)]
        if len({u, v, x, y}) < 4:
            continue
        if rng.random() < .5:
            x, y = y, x
        if a[u, y] or a[x, v]:
            continue
        b = a.copy()
        b[u, v] = b[v, u] = b[x, y] = b[y, x] = 0
        b[u, y] = b[y, u] = b[x, v] = b[v, x] = 1
        if not connected(b):
            continue
        a = b
        swaps += 1
        if swaps == 110:
            return a
    raise RuntimeError('Insufficient accepted rewiring swaps')


def check_inputs():
    """Read-only checks: hashes, panels, graphs and all 100 spatial partitions."""
    manifest = json.loads((ROOT / 'manifest.json').read_text())
    for relative, expected in manifest['sha256'].items():
        if sha(ROOT / relative) != expected:
            raise ValueError(f'Package checksum mismatch: {relative}')
    meta = pd.read_csv(DATA / 'stations.csv', dtype={'site_id': str})
    parts = pd.read_csv(DATA / 'design/partitions.csv', dtype={'site_id': str})
    directions = pd.read_csv(DATA / 'design/directions.csv')
    assert len(meta) == 301 and len(parts) == 15050 and len(directions) == 100
    assert not meta.duplicated(['year', 'site_id']).any()
    assert not parts.duplicated(['year', 'split', 'state', 'site_id']).any()
    assert not directions.duplicated(['year', 'split']).any()
    for year, total in [(2023, 152), (2024, 149)]:
        frames = panels(year)
        assert sum(f.shape[1] for f in frames) == total
        for state, f in zip(STATES, frames):
            assert list(f.index) == list(pd.date_range(f'{year}-06-01', f'{year}-08-31').strftime('%Y-%m-%d'))
            assert f.columns.is_unique and np.isfinite(f.to_numpy()).all() and (f.to_numpy() >= 0).all()
            sites = meta[(meta.year == year) & (meta.state == state)].set_index('site_id')
            assert set(sites.index) == set(f.columns)
            assert sites.valid_days.eq(92).all()
            xy = sites.loc[f.columns, ['longitude', 'latitude']].to_numpy(float)
            xy[:, 0] *= np.cos(np.deg2rad(xy[:, 1].mean()))
            n = max(2, int(np.floor(.2 * len(f.columns))))
            for split in range(CONFIG['splits_per_year']):
                angle = np.random.default_rng(np.random.SeedSequence(
                    [CONFIG['seed'], year, split, 777])).uniform(0, 2 * np.pi)
                recorded = directions[(directions.year == year) & (directions.split == split)]
                assert len(recorded) == 1 and np.isclose(recorded.angle_degrees.iloc[0], np.rad2deg(angle))
                order = np.argsort(xy @ [np.cos(angle), np.sin(angle)], kind='stable')
                z = parts[(parts.year == year) & (parts.split == split) & (parts.state == state)]
                for kind, indices in [('test', order[:n]), ('validation', order[n:2*n]), ('train', order[2*n:])]:
                    g = z[z.partition == kind].sort_values('position')
                    assert g.position.tolist() == list(range(1, len(indices) + 1))
                    assert g.site_id.tolist() == f.columns[indices].tolist()
    centers = pd.read_csv(DATA / 'state_locations.csv', index_col=0).loc[STATES]
    lat, lon = np.deg2rad(centers[['Latitude', 'Longitude']].to_numpy()).T
    h = np.sin((lat[:, None] - lat[None, :])/2)**2 + np.cos(lat[:, None])*np.cos(lat[None, :])*np.sin((lon[:, None]-lon[None, :])/2)**2
    distance = 6371 * 2 * np.arcsin(np.sqrt(np.clip(h, 0, 1)))
    np.fill_diagonal(distance, np.inf)
    net = np.zeros((9, 9))
    for i in range(9):
        net[i, np.argsort(distance[i])[:2]] = 1
    net = np.maximum(net, net.T)
    assert net.sum() == 22 and connected(net)
    expected_graphs = {'NET': net, 'ALL': np.ones((9, 9)) - np.eye(9)}
    expected_graphs.update({f'REWIRE{i+1}': rewire(net, CONFIG['seed']+100+i) for i in range(3)})
    for name, expected in expected_graphs.items():
        raw = pd.read_csv(DATA / f'graphs/graph_{name}_raw.csv', index_col=0)
        normalized = pd.read_csv(DATA / f'graphs/graph_{name}_normalized.csv', index_col=0)
        assert list(raw.index) == list(raw.columns) == STATES
        assert list(normalized.index) == list(normalized.columns) == STATES
        assert np.array_equal(raw.to_numpy(), expected)
        assert np.allclose(normalized.to_numpy(), e.normalize(expected), rtol=1e-14, atol=1e-15)
    print('Input checks passed: 18 complete panels, 301 station-years, 5 graphs, 100 spatial splits.', flush=True)


def run_one(task):
    year, split, output, signature = task
    path = Path(output) / 'fits' / f'{year}_spatial_{split:03d}.json'
    if path.exists():
        old = json.loads(path.read_text())
        if old.get('input_fingerprint') != signature:
            raise ValueError('Existing outputs belong to different data/code; choose a new --output directory.')
        return year, split, 'cached'
    blocks = blocks_for(year, split)
    c = SimpleNamespace(**CONFIG)
    a, va, ta = [cov(blocks, kind) for kind in ['train', 'validation', 'test']]
    ind = e.pca(a, c.rank)
    pool = np.repeat(e.leading(a.sum(0), c.rank)[0][None], len(a), axis=0)
    methods, traces = [], {}
    for method in METHODS:
        gamma = None
        extra = {}
        if method in ['IND', 'POOL']:
            p = ind if method == 'IND' else pool
        else:
            w = pd.read_csv(DATA / f'graphs/graph_{method}_normalized.csv', index_col=0).to_numpy(float)
            fitted, best, boundary, trace, _ = e.tune_doubling(a, va, w, c, pool)
            if fitted is None:
                raise RuntimeError(f'{year}/{split}/{method}: nonconverged candidate')
            p = fitted.p
            gamma = trace[best]['gamma']
            traces[method] = trace
            extra = dict(converged=bool(fitted.converged), sweeps=fitted.sweeps,
                         block_residual=fitted.residual, threshold=fitted.threshold,
                         boundary=bool(boundary), maximum_candidate=max(t['gamma'] for t in trace))
            assert fitted.residual <= fitted.threshold
            assert best == e.choose_index([t['validation_loss'] for t in trace], [t['gamma'] for t in trace], c.tie_tolerance)
            assert e.objective(a, p, w, gamma) <= e.objective(a, pool, w, gamma) + 1e-7
        losses = e.reconstruction(p, ta) * c.scale_ppb**2
        direct = np.array([np.mean((b['test'] - p[k] @ b['test'])**2) * c.scale_ppb**2 for k, b in enumerate(blocks)])
        assert np.allclose(losses, direct, rtol=1e-9, atol=1e-8)
        methods.append(dict(method=method, gamma=gamma, test_mse=float(losses.mean()),
                            state_test_mse=losses.tolist(), **extra))
    save_json(path, dict(year=year, split=split, rank=c.rank, states=STATES,
                        input_fingerprint=signature, methods=methods, traces=traces))
    return year, split, 'fitted'


def describe(output):
    """Full-panel independent-PCA distances; not used for graph or penalty selection."""
    graph = pd.read_csv(DATA / 'graphs/graph_NET_raw.csv', index_col=0).to_numpy()
    rows = []
    for year in CONFIG['years']:
        projectors = []
        for frame in panels(year):
            x = frame.to_numpy(float)
            x -= x.mean(axis=0)
            projectors.append(e.leading(x @ x.T, 2)[0])
        for i in range(9):
            for j in range(i+1, 9):
                rows.append(dict(year=year, state_1=STATES[i], state_2=STATES[j],
                    edge=int(graph[i,j]), distance=float(1-np.sum(projectors[i]*projectors[j])/2)))
    pairs = pd.DataFrame(rows)
    pairs.to_csv(output / 'pair_distances.csv', index=False)
    pairs.groupby(['year', 'edge']).distance.agg(['size', 'mean']).to_csv(output / 'pair_distance_summary.csv')


def summarize(output):
    signature = fingerprint()
    overall, by_state, controls = [], [], []
    for year in CONFIG['years']:
        for split in range(CONFIG['splits_per_year']):
            path = output / 'fits' / f'{year}_spatial_{split:03d}.json'
            if not path.exists():
                raise ValueError('A full summary requires all 100 fits; use run or all first.')
            result = json.loads(path.read_text())
            assert result['input_fingerprint'] == signature
            assert result['year'] == year and result['split'] == split and result['rank'] == 2
            assert result['states'] == STATES
            methods = {m['method']: m for m in result['methods']}
            assert set(methods) == set(METHODS)
            base = methods['IND']
            for name in METHODS:
                m = methods[name]
                assert np.isclose(m['test_mse'], np.mean(m['state_test_mse']))
                overall.append(dict(year=year, split=split, method=name, mse=m['test_mse'],
                                    reduction=100*(1-m['test_mse']/base['test_mse'])))
            for k, state in enumerate(STATES):
                by_state.append(dict(year=year, split=split, state=state,
                    reduction=100*(1-methods['NET']['state_test_mse'][k]/base['state_test_mse'][k])))
            for name in ['ALL', 'REWIRE1', 'REWIRE2', 'REWIRE3']:
                controls.append(dict(year=year, split=split, comparator=name,
                    reduction=100*(1-methods['NET']['test_mse']/methods[name]['test_mse'])))
    d = pd.DataFrame(overall)
    d.to_csv(output / 'split_metrics.csv', index=False)
    table = d.groupby(['method','year']).agg(mean_mse=('mse','mean'), mean_reduction=('reduction','mean')).reindex(
        pd.MultiIndex.from_product([METHODS, CONFIG['years']], names=['method','year']))
    table.to_csv(output / 'table4.csv')
    lines = [r'\begin{tabular}{lrrrr}', r'\hline',
             r'Method & 2023 MSE & Reduction (\%) & 2024 MSE & Reduction (\%) \\', r'\hline']
    for method, label in zip(METHODS, NAMES):
        cells = [label]
        for year in CONFIG['years']:
            row = table.loc[(method, year)]
            cells += [f'{row.mean_mse:.3f}', r'\textemdash' if method == 'IND' else f'{row.mean_reduction:.2f}']
        lines.append(' & '.join(cells) + r' \\')
    (output / 'table4.tex').write_text('\n'.join(lines + [r'\hline', r'\end{tabular}']) + '\n')
    state_rows = pd.DataFrame(by_state)
    state_rows.to_csv(output / 'state_split_metrics.csv', index=False)
    state_rows.groupby(['year','state']).reduction.agg(
        n='size', mean_gain='mean', median_gain='median', q25=lambda x:x.quantile(.25),
        q75=lambda x:x.quantile(.75), harm_fraction=lambda x:(x < -1e-8).mean()).to_csv(output / 'state_summary.csv')
    pd.DataFrame(controls).groupby(['year','comparator']).reduction.agg(
        mean_reduction='mean', win_fraction=lambda x:(x>1e-8).mean()).to_csv(output / 'network_vs_controls.csv')
    describe(output)
    print('Generated full 50-split-per-year summaries in', output, flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=['check', 'smoke', 'run', 'summarize', 'all'], default='all')
    parser.add_argument('--workers', type=int, default=4)
    parser.add_argument('--output', type=Path, default=ROOT / 'outputs')
    args = parser.parse_args()
    if args.workers < 1:
        parser.error('--workers must be positive')
    check_inputs()
    if args.mode == 'check':
        return
    output = args.output.expanduser().resolve()
    if output == ROOT or DATA == output or DATA in output.parents or ROOT/'code' == output or ROOT/'code' in output.parents:
        parser.error('Use a separate output directory, not the package root, data or code.')
    output.mkdir(parents=True, exist_ok=True)
    signature = fingerprint()
    if args.mode in ['smoke', 'run', 'all']:
        save_json(output / 'run_environment.json', dict(python=platform.python_version(),
            numpy=np.__version__, pandas=pd.__version__, input_fingerprint=signature,
            mode=args.mode, splits_per_year=1 if args.mode=='smoke' else CONFIG['splits_per_year']))
        splits = [0] if args.mode == 'smoke' else range(CONFIG['splits_per_year'])
        tasks = [(year, split, str(output), signature) for year in CONFIG['years'] for split in splits]
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            futures = [pool.submit(run_one, task) for task in tasks]
            for i, future in enumerate(as_completed(futures), 1):
                print(f'{i}/{len(tasks)}:', future.result(), flush=True)
    if args.mode in ['summarize', 'all']:
        summarize(output)
        from figures import make_figures
        make_figures(output)
    if args.mode == 'smoke':
        print('Smoke test only: one split per year. These are not manuscript summaries.')


if __name__ == '__main__':
    main()
