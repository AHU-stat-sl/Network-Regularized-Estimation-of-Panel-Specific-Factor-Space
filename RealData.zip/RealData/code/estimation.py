"""Spectral estimator used in the ozone application.

The numerical functions through tune_doubling are preserved from the original
empirical implementation. Unused alternative tuning routines are omitted.
"""
from __future__ import annotations
import os
for _name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS",
              "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[_name] = "1"
import math
import time
from dataclasses import dataclass
import numpy as np

def qf(x):
    q, r = np.linalg.qr(x, mode="reduced")
    return q * np.where(np.diag(r) < 0, -1., 1.)


def projector(q):
    return q @ np.swapaxes(q, -1, -2)


def leading(a, rank):
    values, vectors = np.linalg.eigh(a)
    u = vectors[:, -rank:]
    return u @ u.T, float(values[-rank:].sum())


def pca(a, rank):
    return np.asarray([leading(x, rank)[0] for x in a])


def path_graph(order):
    raw = np.zeros((len(order), len(order)))
    for i, j in zip(order[:-1], order[1:]):
        raw[i, j] = raw[j, i] = 1.
    return raw


def normalize(raw):
    degrees = raw.sum(axis=1)
    inv = np.zeros_like(degrees)
    np.divide(1., np.sqrt(degrees), out=inv, where=degrees > 0)
    return raw * inv[:, None] * inv[None, :]


def covariances(xs):
    return xs @ xs.transpose(0, 2, 1) / (xs.shape[1] * xs.shape[2])


def objective(a, p, w, gamma):
    """Dropped-constant Q_gamma, exactly as in the manuscript's stopping rule."""
    flat = p.reshape(len(p), -1)
    overlap = flat @ flat.T
    return -float(np.sum(a * p)) - gamma * float(np.sum(np.triu(w * overlap, 1)))


def residual(a, p, w, gamma, rank):
    gains = []
    for k in range(len(a)):
        js = np.flatnonzero(w[k])
        agg = np.sum(w[k, js, None, None] * p[js], axis=0)
        v = a[k] + gamma * agg
        top = np.linalg.eigvalsh(v)[-rank:].sum()
        gains.append(max(0., float(top - np.sum(v * p[k]))))
    return max(gains, default=0.)


def reconstruction(p, a):
    return np.trace(a, axis1=1, axis2=2) - np.sum(p * a, axis=(1, 2))


def errors(p, truth, rank):
    return np.clip(1 - np.sum(p * truth, axis=(1, 2)) / rank, 0., 1.)


@dataclass
class Fit:
    p: np.ndarray
    sweeps: int
    residual: float
    threshold: float
    value: float
    converged: bool
    reason: str = ""


def fit(a, w, gamma, c, initial, threshold=None):
    p = initial.copy()
    if threshold is None:
        threshold = c.tolerance * (1 + max(np.linalg.eigvalsh(x)[-1] for x in a))
    if gamma == 0:
        p = pca(a, c.rank)
        return Fit(p, 0, residual(a, p, w, 0., c.rank), float(threshold),
                   objective(a, p, w, 0.), True)
    value = objective(a, p, w, gamma)
    neighbors = [np.flatnonzero(row) for row in w]
    # A continuous 6000-sweep limit equals 1200 then 4800 from the same iterate.
    cap = c.first_sweeps + c.continuation_sweeps
    for sweep in range(1, cap + 1):
        old = value
        for k, js in enumerate(neighbors):
            agg = np.sum(w[k, js, None, None] * p[js], axis=0)
            p[k] = leading(a[k] + gamma * agg, c.rank)[0]
        value = objective(a, p, w, gamma)
        if not math.isfinite(value) or value > old + 1e-9 * (1 + abs(old)):
            return Fit(p, sweep, residual(a, p, w, gamma, c.rank), float(threshold),
                       value, False, "objective_increase_or_nonfinite")
        if abs(old - value) / (1 + abs(old)) < c.tolerance:
            gain = residual(a, p, w, gamma, c.rank)
            if gain <= threshold:
                return Fit(p, sweep, gain, float(threshold), value, True)
    return Fit(p, cap, residual(a, p, w, gamma, c.rank), float(threshold),
               value, False, "sweep_limit")


def choose_index(scores, gammas, tolerance):
    minimum = min(scores)
    allowed = tolerance * (1 + abs(minimum))
    return min((i for i, s in enumerate(scores) if s <= minimum + allowed),
               key=lambda i: gammas[i])


def tune_doubling(a, val, w, c, pooled):
    """Has no truth/test arguments, preventing truth- or test-dependent tuning."""
    grid = list(c.grid)
    current = pca(a, c.rank)
    threshold = c.tolerance * (1 + max(np.linalg.eigvalsh(x)[-1] for x in a))
    scores, candidates, trace = [], [], []
    extensions = 0
    index = 0
    while index < len(grid):
        gamma = grid[index]
        initial, initial_name = current, "path"
        if gamma and objective(a, pooled, w, gamma) < objective(a, current, w, gamma):
            initial, initial_name = pooled, "component_pool"
        started = time.monotonic()
        f = fit(a, w, gamma, c, initial, threshold)
        elapsed = time.monotonic() - started
        score = float(reconstruction(f.p, val).mean())
        trace.append(dict(gamma=gamma, validation_loss=score, objective=f.value,
                          block_residual=f.residual, residual_threshold=f.threshold,
                          sweeps=f.sweeps, continued=int(f.sweeps > c.first_sweeps),
                          converged=int(f.converged), initial=initial_name,
                          elapsed_seconds=elapsed, failure_reason=f.reason))
        candidates.append(f)
        scores.append(score)
        if not f.converged:
            return None, None, False, trace, candidates
        current = f.p
        best = choose_index(scores, grid[:len(scores)], c.tie_tolerance)
        if index == len(grid) - 1 and best == index and extensions < c.max_extensions:
            grid.append(2 * grid[-1])
            extensions += 1
        index += 1
    best = choose_index(scores, grid, c.tie_tolerance)
    return candidates[best], best, best == len(grid) - 1, trace, candidates

