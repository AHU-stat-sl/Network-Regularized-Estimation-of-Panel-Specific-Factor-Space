# Data dictionary and preparation rules

All CSV files are UTF-8 (some retain a UTF-8 BOM from the original export).
Site identifiers must be treated as strings, preserving leading zeros and
hyphens. Years are analyzed separately; the 301 records are station-years,
not 301 distinct sites.

## Concentration matrices

`data/panels/YYYY/SS_State_Name.csv`: `SS` is the two-digit state code.
The first column, `date`, is the local calendar date (`YYYY-MM-DD`). The other
columns are AQS site IDs (`state-county-site`, e.g. `17-001-0007`). Each file has
92 rows, from June 1 through August 31. Values are uncentered daily maximum
eight-hour ozone concentrations in parts per billion (ppb). No values are
missing, imputed, clipped or variance-standardized. Centering and the fixed
10 ppb scaling occur in the analysis code.

| State | 2023 sites | 2024 sites |
| --- | ---: | ---: |
| Illinois | 13 | 14 |
| Indiana | 13 | 16 |
| Kentucky | 12 | 11 |
| Michigan | 11 | 14 |
| North Carolina | 22 | 19 |
| Ohio | 34 | 35 |
| Pennsylvania | 12 | 10 |
| Virginia | 13 | 14 |
| Wisconsin | 22 | 16 |

Original response: EPA `1st Max Value` multiplied by 1000, with
`Sample Duration = 8-HR RUN AVG BEGIN HOUR`,
`Pollutant Standard = Ozone 8-hour 2015`, and original units parts per million.
Records with `Event Type = Excluded` were removed to avoid alternative summary
versions; this is not exclusion of all exceptional-event days. A valid value is
finite and nonnegative, with `75 <= Observation Percent <= 100`. Observation
Percent is within-day coverage, not coverage of the entire summer.

One POC series per site was chosen using the largest number of valid days across
2023 and 2024, with ties broken by more reported days and then the smaller POC.
The chosen POC is fixed across years. Each annual panel retains sites with all
92 valid summer dates. The use of both years for selection means 2024 is a
repeat application, not an untouched prospective test sample.

## Site and network metadata

`data/stations.csv`: `year`, `state`, `site_id`, `POC` (parameter occurrence
code), `latitude` and `longitude` (degrees), `valid_days` (92). These are the
sites in the final annual panels and the coordinates used for spatial ordering.

`data/state_locations.csv`: `State Name`, `Latitude`, `Longitude` (degrees).
These are coordinatewise medians of site locations across **all selected-POC
series in the nine states**, including sites outside the final complete-record
annual panels. Site locations were first aggregated across their records by
coordinatewise median, then across sites within each state. Consequently, these
state representatives must not be recomputed using only `stations.csv`.
They are neither administrative centroids nor border-adjacency indicators.

`data/graphs/graph_METHOD_raw.csv`: 9 by 9 symmetric, zero-diagonal adjacency
matrix, with state labels on both axes. `NET` is the union of each state's two
nearest neighbors, using haversine distances (Earth radius 6371 km); it has 11
edges. `ALL` is complete. `REWIRE1` through `REWIRE3` use 110 accepted connected,
degree-preserving edge swaps, with seeds 20261123, 20261124 and 20261125.
`graph_METHOD_normalized.csv` contains `D^(-1/2) W D^(-1/2)`.
All graphs are fixed across years and use no concentration values.

## Spatial design inputs

`data/design/directions.csv`: `year`, `split` (0 through 49), `partition_key`
(original year/design/split identifier), `angle_degrees` (degrees).
Directions were sampled uniformly from `[0, 2*pi)` with NumPy's default generator
and `SeedSequence([20261023, year, split, 777])`. The same angle is used in all
nine states for a given year and split.

Within a state-year, longitude is multiplied by `cos(mean latitude in radians)`.
The coordinates are projected onto `(cos(angle), sin(angle))`, then sorted
in ascending order with a stable sort; ties retain input column order.

`data/design/partitions.csv`: `year`, `split`, `state`, `partition`
(`train`, `validation`, `test`), `position` (one-based order within a block),
`site_id`. These 15,050 rows are design records, not fitted results. They fix
the exact assignment and ordering used by every method and are the inputs used
by the reproduction runner; `check` independently regenerates and verifies them.

## Independent-PCA space distance

For the descriptive network figure, each full state-year panel is time-centered,
and its leading two left singular vectors define projector `P`. For each of the
36 distinct state pairs per year, distance is `1 - trace(P_i P_j)/2`.
All 11 linked and 25 unlinked pairs are retained. Group means are descriptive;
no test treating these dependent pairs as independent is performed.
